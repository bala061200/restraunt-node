const express = require('express');
const app = express();
const PORT = 4000;
const cors = require('cors');

app.use(cors({
  "origin": "*",
  "methods": "GET,HEAD,PUT,PATCH,POST,DELETE",
  "preflightContinue": false,
  "optionsSuccessStatus": 204
}));

const mongoose = require('mongoose');

const db1URL = "mongodb+srv://balakrishnan:91yeB1zeMJMmry79@cluster0.10tzniz.mongodb.net/Restraunt_1?retryWrites=true&w=majority";
const db2URL = "mongodb+srv://balakrishnan:91yeB1zeMJMmry79@cluster0.10tzniz.mongodb.net/Restraunt_2?retryWrites=true&w=majority";

// Create connections
const db1 = mongoose.createConnection(db1URL, { useNewUrlParser: true, useUnifiedTopology: true, connectTimeoutMS: 30000 });
const db2 = mongoose.createConnection(db2URL, { useNewUrlParser: true, useUnifiedTopology: true, connectTimeoutMS: 30000 });

// Define schemas for each database
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
});

// Create models for each database using the corresponding connection
const User1 = db1.model('User', userSchema);
const User2 = db2.model('User', userSchema);

app.get('/user', async (req, res, next) => {
  try {
    const userdetails = await User1.create({
      name: "balakrishann",
      email: "balakrf@gmail.com"
    });

    res.status(200).send({ userdetails });
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

app.listen(PORT, () => console.log("server listening"));
